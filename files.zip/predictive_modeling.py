"""
Predictive Modeling Using Machine Learning
============================================
Dataset : car.csv (12,000 vehicle sensor/maintenance records)
Task 1  : Binary classification - predict Accident_History (Yes/No)
          using Decision Tree and Random Forest
Task 2  : Regression (bonus) - predict Remaining_KM using Linear Regression
Outputs : trained models, metrics, confusion matrices, ROC curves,
          feature importance chart, regression diagnostic chart
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_curve, roc_auc_score, ConfusionMatrixDisplay,
    mean_absolute_error, mean_squared_error, r2_score
)

OUT = "outputs"
RANDOM_STATE = 42
plt.rcParams.update({"figure.dpi": 130, "font.size": 10})

# ---------------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------------
df = pd.read_csv("/mnt/user-data/uploads/car.csv")
print("Dataset shape:", df.shape)
print(df["Accident_History"].value_counts(normalize=True))

# ---------------------------------------------------------------
# 2. PREPROCESSING
# ---------------------------------------------------------------
data = df.copy()

# Target
target_le = LabelEncoder()
data["Accident_History"] = target_le.fit_transform(data["Accident_History"])  # No=0, Yes=1

# Ordinal encode Tire_Condition (has a natural order)
tire_order = {"Good": 0, "Moderate": 1, "Worn": 2, "Critical": 3}
data["Tire_Condition"] = data["Tire_Condition"].map(tire_order)

vib_order = {"Low": 0, "Medium": 1, "High": 2}
data["Vibration_Level"] = data["Vibration_Level"].map(vib_order)

# One-hot encode nominal categorical: Vehicle_Type
data = pd.get_dummies(data, columns=["Vehicle_Type"], drop_first=True)

# KM_Range_Before_Defect is a categorical bucket derived from Remaining_KM
# (leaks the regression target) -> drop for the classification task
class_features = [c for c in data.columns
                   if c not in ["Accident_History", "KM_Range_Before_Defect", "Remaining_KM"]]

X = data[class_features]
y = data["Accident_History"]

print("\nFeatures used for classification:", list(X.columns))

# ---------------------------------------------------------------
# 3. TRAIN / TEST SPLIT
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------------------------------------------------------------
# 4. TRAIN MODELS
# ---------------------------------------------------------------
dt = DecisionTreeClassifier(max_depth=6, min_samples_leaf=20,
                             class_weight="balanced", random_state=RANDOM_STATE)
dt.fit(X_train, y_train)

rf = RandomForestClassifier(
    n_estimators=300, max_depth=10, min_samples_leaf=5,
    class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
)
rf.fit(X_train, y_train)

models = {"Decision Tree": dt, "Random Forest": rf}

# ---------------------------------------------------------------
# 5. EVALUATE
# ---------------------------------------------------------------
results = {}
for name, model in models.items():
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    results[name] = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "auc": roc_auc_score(y_test, y_prob),
        "y_pred": y_pred,
        "y_prob": y_prob,
    }
    print(f"\n{name}")
    for k in ["accuracy", "precision", "recall", "f1", "auc"]:
        print(f"  {k:9s}: {results[name][k]:.4f}")

# ---------------------------------------------------------------
# 6. VISUALIZE - Confusion Matrices
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, (name, model) in zip(axes, models.items()):
    cm = confusion_matrix(y_test, results[name]["y_pred"])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["No Accident", "Accident"])
    disp.plot(ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title(f"{name}\nAccuracy = {results[name]['accuracy']:.3f}")
plt.tight_layout()
plt.savefig(f"{OUT}/confusion_matrices.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------------
# 7. VISUALIZE - ROC Curves
# ---------------------------------------------------------------
plt.figure(figsize=(6, 5.5))
for name in models:
    fpr, tpr, _ = roc_curve(y_test, results[name]["y_prob"])
    plt.plot(fpr, tpr, label=f"{name} (AUC = {results[name]['auc']:.3f})", linewidth=2)
plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random guess")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve — Predicting Accident History")
plt.legend(loc="lower right")
plt.tight_layout()
plt.savefig(f"{OUT}/roc_curve.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------------
# 8. FEATURE IMPORTANCE (Random Forest)
# ---------------------------------------------------------------
importances = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=True)
plt.figure(figsize=(7, 6))
importances.plot(kind="barh", color="#4C72B0")
plt.title("Random Forest — Feature Importance")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig(f"{OUT}/feature_importance.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------------
# 9. BONUS: LINEAR REGRESSION on Remaining_KM
# ---------------------------------------------------------------
reg_features = [c for c in data.columns
                 if c not in ["Accident_History", "KM_Range_Before_Defect", "Remaining_KM"]]
Xr = data[reg_features]
yr = data["Remaining_KM"]

Xr_train, Xr_test, yr_train, yr_test = train_test_split(
    Xr, yr, test_size=0.25, random_state=RANDOM_STATE
)

lin = LinearRegression()
lin.fit(Xr_train, yr_train)
yr_pred = lin.predict(Xr_test)

reg_metrics = {
    "MAE": mean_absolute_error(yr_test, yr_pred),
    "RMSE": np.sqrt(mean_squared_error(yr_test, yr_pred)),
    "R2": r2_score(yr_test, yr_pred),
}
print("\nLinear Regression (Remaining_KM)")
for k, v in reg_metrics.items():
    print(f"  {k:5s}: {v:.3f}")

plt.figure(figsize=(6, 5.5))
plt.scatter(yr_test, yr_pred, alpha=0.25, s=12, color="#55A868")
lims = [min(yr_test.min(), yr_pred.min()), max(yr_test.max(), yr_pred.max())]
plt.plot(lims, lims, "--", color="gray")
plt.xlabel("Actual Remaining KM")
plt.ylabel("Predicted Remaining KM")
plt.title(f"Linear Regression — Actual vs Predicted\nR² = {reg_metrics['R2']:.3f}")
plt.tight_layout()
plt.savefig(f"{OUT}/regression_actual_vs_predicted.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------------
# 10. SAVE METRICS SUMMARY
# ---------------------------------------------------------------
summary = pd.DataFrame({
    name: {k: results[name][k] for k in ["accuracy", "precision", "recall", "f1", "auc"]}
    for name in models
}).T
summary.to_csv(f"{OUT}/classification_metrics.csv")
pd.Series(reg_metrics).to_csv(f"{OUT}/regression_metrics.csv")

print("\nAll outputs saved to", OUT)
